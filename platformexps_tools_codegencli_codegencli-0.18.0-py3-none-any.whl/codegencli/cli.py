import subprocess

import click

from codegencli.scripts.commands.enrich import enrich_local_dir
from codegencli.scripts.commands.proxy_tunnel import start_proxy_tunnel
from codegencli.scripts.commands.validation import (
    add_missing_validations,
    refresh_existing_validations,
    run_validation_tests,
)


def set_git_post_buffer():
    """
    Set the Git http.postBuffer configuration globally.
    see https://stackoverflow.com/questions/39938153/how-to-increase-git-post-size
    """
    try:
        subprocess.run(
            ["git", "config", "--global", "http.postBuffer", "524288000"], check=True
        )
        click.echo("Successfully set http.postBuffer to 524288000 globally.")
    except subprocess.CalledProcessError as e:
        click.echo(f"An error occurred while setting http.postBuffer: {e}")


@click.group()
def cli():
    """
    A CLI tool for validation and enrichment tasks.

    This function sets up the CLI group, allowing for the addition of multiple commands.
    """
    set_git_post_buffer()  # Ensure the Git configuration is set before any command


@click.command()
@click.option("--add-missing", is_flag=True, help="Add missing expected responses.")
@click.option("--refresh", is_flag=True, help="Refresh existing expected responses.")
@click.option("--run-tests", is_flag=True, help="Run validation tests.")
def validation(add_missing, refresh, run_tests):
    """
    Perform validation tasks based on the provided options.

    This command allows users to either add missing expected responses or refresh existing ones.

    Args:
        add_missing (bool): Flag to add missing expected responses.
        refresh (bool): Flag to refresh existing expected responses.
        run_tests (bool): Flag to run validation tests.

    Returns:
        None
    """
    if add_missing or refresh or run_tests:
        if add_missing:
            click.echo("Adding missing expected responses...")
            add_missing_validations()
        if refresh:
            click.echo("Refreshing existing expected responses...")
            refresh_existing_validations()
        if run_tests:
            click.echo("Running validation tests...")
            run_validation_tests()
    else:
        click.echo("No options provided for validation.")


@click.command()
def enrich():
    """
    Perform enrichment tasks.

    This command is a placeholder for future enrichment features.

    Returns:
        None
    """
    click.echo("Enriching the code examples")
    enrich_local_dir()


@click.command()
@click.option(
    "--model",
    default="anthropic.claude-3-haiku-20240307-v1-0",
    help="The name of the Intuit LLM model to use",
)
@click.option(
    "--port", default=5000, type=int, help="The local port to use for the proxy tunnel"
)
def proxy_tunnel(model, port):
    """
    Create a proxy tunnel to access Intuit's LLM model.

    This command starts a local server to capture user authentication details,
    then creates a proxy tunnel to access Intuit's LLM model.

    Returns:
        None
    """
    click.echo("Starting Intuit LLM proxy tunnel...")
    start_proxy_tunnel(model_name=model, tunnel_port=port)


# Add commands to the CLI group
cli.add_command(validation)
cli.add_command(enrich)
cli.add_command(proxy_tunnel)

if __name__ == "__main__":
    cli()  # Execute the CLI
