import json
import re

import requests

from codegencli.scripts.constants.secrets import get_simple_auth_key_codegen


def prepare_request_payload(prompt, tag=None):
    """
    Prepares the payload for the CodeGen service request.

    Args:
        prompt (str): The input prompt for which the response is requested.
        tag (str, optional): A tag to include in the request payload.

    Returns:
        dict: A dictionary containing user data and the prompt.
    """
    # Construct the payload with user data and prompt
    payload = {
        "user_data": {
            "installation_id": "12c19e7c-f554-4cd3-b67b-11ebd76ccb70",
            "editor_version": "1.91.1",
            "extension_version": "0.9.10",
            "os_platform": "darwin",
            "os_version": "v20.9.0",
            "editor_type": "vscode",
        },
        "max_remote_context": 5,
        "chat_input": prompt.strip(),
    }

    # Add tag to payload if provided
    if tag is not None:
        payload["remote_context_tags"] = [tag]

    return payload


def call_codegen_service(payload, log_level):
    """
    Calls the CodeGen service with the given payload and handles the response.

    Args:
        payload (dict): The payload to send in the request.
        log_level (str): The log level for logging messages.

    Returns:
        str or None: The response text if successful, otherwise None.
    """
    print(f"[{log_level}] Calling CodeGen service.")
    try:
        # Send a POST request to the CodeGen service
        response = requests.post(
            f"https://codiumaicodiumate-qal.api.intuit.com/cli-qodo/v2/chats/chat?intuit_apikey={get_simple_auth_key_codegen()}",
            headers={"Content-Type": "application/json"},
            data=json.dumps(payload),
        )
        if response.status_code == 200:
            print(f"[{log_level}] Received successful response from CodeGen service.")
            return response.text
        else:
            handle_response_error(response.status_code, log_level)
    except requests.exceptions.RequestException as e:
        print(f"[{log_level}] Request failed: {e}")
    return None


def handle_response_error(status_code, log_level):
    """
    Handles errors based on the HTTP status code received from the CodeGen service.

    Args:
        status_code (int): The HTTP status code from the response.
        log_level (str): The log level for logging messages.

    Returns:
        None
    """
    # Define error messages for specific status codes
    error_messages = {
        400: "Bad Request: The server could not understand the request due to invalid syntax.",
        401: "Unauthorized: Access is denied due to invalid credentials.",
        404: "Not Found: The requested resource could not be found.",
        500: "Internal Server Error: The server encountered an unexpected condition.",
    }
    print(
        f"[{log_level}] {error_messages.get(status_code, 'Unexpected status code: ' + str(status_code))}"
    )


def process_response(response):
    """
    Processes the response from the CodeGen service to extract relevant content.

    Args:
        response (str): The raw response text from the CodeGen service.

    Returns:
        str: The processed response content.
    """
    response_content = ""
    # Iterate over each line in the response
    for line in response.splitlines():
        if line.strip():
            # Parse JSON line and extract content
            json_line = json.loads(line)
            content = json_line.get("data", {}).get("content", "")
            if "From the repository" not in content:
                response_content += content
    return response_content


def extract_plaintext(llm_output: str) -> str:
    """
    Extracts plaintext content from the LLM output enclosed in ```plaintext```, ```markdown```, or ``` markers.

    Args:
        llm_output (str): The output from the LLM.

    Returns:
        str: The extracted plaintext content, or the input string with spaces and newlines removed if no markers are found.
    """
    # Regex pattern to match ```plaintext{text}```, ```markdown{text}```, and ```{text}```
    pattern = re.compile(r"```(?:plaintext|markdown)?(.*?)```", re.DOTALL)
    match = pattern.search(llm_output)

    if match:
        extracted_text = match.group(1).strip()
        return extracted_text.replace("\n", "").replace(" ", "")
    else:
        return llm_output.replace("\n", "").replace(" ", "")


def get_processed_response(prompt, log_level, tag=None):
    """
    Gets the processed response from the CodeGen service for a given prompt.

    Args:
        prompt (str): The input prompt for which the response is requested.
        log_level (str): The log level for logging messages.
        tag (str, optional): A tag to include in the request payload.

    Returns:
        str: The processed response content.
    """
    payload = prepare_request_payload(prompt, tag)
    response = call_codegen_service(payload, log_level)
    return process_response(response)


def get_file_name(text, log_level):
    """
    Generates a file name in kebab case with a .md extension based on the given text.

    Args:
        text (str): The text to base the file name on.
        log_level (str): The log level for logging messages.

    Returns:
        str: The generated file name.
    """
    prompt = f"""
    Create a very short name of a file with .md extension to save the LLM response against a given prompt.
    ## prompt ##
    {text}

    - File name should be in kebab case.
    - Your output should only contain the name of the file in simple text and nothing else. e.g. new-file.md

    ## file name ##
    """
    return extract_plaintext(get_processed_response(prompt, log_level))
