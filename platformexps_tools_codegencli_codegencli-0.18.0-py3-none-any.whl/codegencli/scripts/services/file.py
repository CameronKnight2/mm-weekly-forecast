import os
import shutil

import toml
import yaml
from ruamel.yaml import YAML
from ruamel.yaml.scalarstring import LiteralScalarString

from codegencli.scripts.services.ai import get_file_name


def read_yaml_file(file_path, log_level="main"):
    """
    Reads and parses a YAML file from the specified path, removing leading and trailing newlines from strings.

    Args:
        file_path (str): The path to the YAML file.
        log_level (str): The log level for logging messages.

    Returns:
        dict: The parsed YAML data with newlines stripped from strings.
    """
    print(f"[{log_level}] Reading YAML file from: {file_path}")
    with open(file_path, "r") as file:
        data = yaml.safe_load(file)

    def strip_newlines(obj):
        if isinstance(obj, str):
            return obj.strip()
        elif isinstance(obj, dict):
            return {k: strip_newlines(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [strip_newlines(elem) for elem in obj]
        else:
            return obj

    return strip_newlines(data)


def save_yaml_file(file_path, data, log_level="main"):
    """
    Saves data to a YAML file at the specified path, converting multiline strings to preserve their format.

    Args:
        file_path (str): The path to the YAML file.
        data (dict): The data to save to the file.
        log_level (str): The log level for logging messages.

    Returns:
        None
    """
    print(f"[{log_level}] Saving updated YAML data to file: {file_path}")
    yaml_instance = YAML()
    yaml_instance.width = 4096

    # Convert multiline strings to LiteralScalarString to preserve multiline format
    for test_case in data["testCases"]:
        if "prompt" in test_case:
            prompt = test_case["prompt"]
            if "\n" in prompt:  # Check if the string is multiline
                test_case["prompt"] = LiteralScalarString(prompt)

    with open(file_path, "w") as file:
        yaml_instance.dump(data, file)


def save_response_to_file(prompt, response_content, log_level="main"):
    """
    Saves the response content to a file named based on the prompt.

    Args:
        prompt (str): The input prompt for which the response was generated.
        response_content (str): The content of the response to save.
        log_level (str): The log level for logging messages.

    Returns:
        str: The path to the saved response file.
    """
    # Generate a file name using the prompt and log level
    file_name = get_file_name(prompt, log_level)
    # Construct the full file path
    file_path = os.path.join(os.getcwd(), "validations", file_name)
    print(f"[{log_level}] Saving response to file: {file_path}")
    # Write the response content to the file
    with open(file_path, "w") as response_file:
        response_file.write(response_content)
    # Return the relative path to the file
    return os.path.join("/", file_name)


def read_key_from_toml(toml_file_path, key_path):
    """
    Reads a value from a TOML file given a path of keys.
    :param toml_file_path: Path to the TOML file.
    :param key_path: List of keys representing the path to the desired value.
    :return: The value found at the specified path, or None if not found.
    """
    try:
        # Load the TOML file
        with open(toml_file_path, "r") as file:
            data = toml.load(file)

        # Navigate through the nested keys
        section = data
        for key in key_path:
            section = section.get(key)
            if section is None:
                print(f"[main] Path '{'.'.join(key_path)}' not found in the TOML file.")
                return None

        print(f"[main] Value found at path '{'.'.join(key_path)}': {section}")
        return section

    except FileNotFoundError:
        print(f"[main] The file '{toml_file_path}' does not exist.")
        raise Exception(f"[main] The file '{toml_file_path}' does not exist.")
    except toml.TomlDecodeError:
        print("[main] Error decoding the TOML file. Please check the file format.")
        raise Exception(
            "[main] Error decoding the TOML file. Please check the file format."
        )
    except Exception as e:
        print(f"[main] An error occurred: {e}")
        raise Exception(f"[main] An error occurred: {e}")


def update_ai_config(toml_file_path, key_path, new_value):
    """
    Update a value in a TOML file at a specified key path.

    This function reads a TOML file, navigates through the specified
    nested key path, updates the value at the final key, and writes
    the changes back to the file.

    Args:
        toml_file_path (str): The path to the TOML file to be updated.
        key_path (list of str): A list of keys representing the path to
            the value to be updated.
        new_value: The new value to set at the specified key path.

    Raises:
        FileNotFoundError: If the specified TOML file does not exist.
        toml.TomlDecodeError: If there is an error decoding the TOML file.
        Exception: For any other exceptions that occur during the process.
    """
    try:
        # Load the existing TOML file
        with open(toml_file_path, "r") as file:
            data = toml.load(file)

        # Navigate through the nested keys to update the value
        current_level = data
        for key in key_path[:-1]:
            current_level = current_level.setdefault(key, {})

        # Update the final key with the new value
        current_level[key_path[-1]] = new_value

        # Write the updated data back to the TOML file
        with open(toml_file_path, "w") as file:
            toml.dump(data, file)

    except FileNotFoundError:
        print(f"[main] The file '{toml_file_path}' does not exist.")
    except toml.TomlDecodeError:
        print(
            f"[main] Error decoding file {toml_file_path}. Please check the file format."
        )
    except Exception as e:
        print(f"[main] An error occurred: {e}")


def copy_folder(src_dir, dest_dir):
    """
    Copies all files and subdirectories from src_dir to dest_dir,
    excluding the .git directory.

    :param src_dir: The source directory to copy from.
    :param dest_dir: The destination directory to copy to.
    """
    if not os.path.exists(src_dir):
        raise ValueError(f"Source directory {src_dir} does not exist.")

    if not os.path.exists(dest_dir):
        os.makedirs(dest_dir)

    for item in os.listdir(src_dir):
        if item == ".git":
            continue  # Skip the .git directory

        src_item = os.path.join(src_dir, item)
        dest_item = os.path.join(dest_dir, item)

        if os.path.isdir(src_item):
            shutil.copytree(src_item, dest_item)
        else:
            shutil.copy2(src_item, dest_item)
