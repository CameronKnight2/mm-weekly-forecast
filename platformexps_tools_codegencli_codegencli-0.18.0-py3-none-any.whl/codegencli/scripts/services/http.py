import http.server
import os
import socket
import socketserver


def find_available_port(start_port):
    """
    Finds an available port starting from the specified start_port.

    Args:
        start_port (int): The port number to start checking from.
        log_level (str): The log level for logging messages.

    Returns:
        int: An available port number.
    """
    port = start_port
    while True:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("", port))
                return port
            except OSError:
                port += 1


def start_server(directory_path, port, log_level="main"):
    """
    Starts an HTTP server to serve files from the specified directory.

    Args:
        directory_path (str): The path to the directory to serve.
        start_port (int): The port number to start checking from.
        log_level (str): The log level for logging messages.
    """
    # Change the working directory to the specified path
    os.chdir(directory_path)

    # Custom handler to disable logging
    class QuietHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, format, *args):
            pass  # Override to disable logging

    # Create a custom TCPServer class to set allow_reuse_address
    class CustomTCPServer(socketserver.TCPServer):
        allow_reuse_address = True

    # Use the custom server class with the quiet handler
    httpd = CustomTCPServer(("", port), QuietHTTPRequestHandler)
    print(f"[{log_level}] Serving at port {port} from directory {directory_path}")
    httpd.serve_forever()
