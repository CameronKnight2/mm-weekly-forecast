import json

import requests
from requests import RequestException

from codegencli.scripts.constants.constants import METADATA_CATALOG_SVC_BASE_URL
from codegencli.scripts.constants.secrets import get_simple_auth_key


def refresh_metadata_tags(
    env, codium_metadata_service_url, api_key, intuit_tid, log_level="main"
):
    """
    Refreshes metadata tags for a given environment and metadata service URL.

    Args:
        env (str): The environment for which to refresh metadata tags.
        codium_metadata_service_url (str): The URL of the metadata service.
        api_key (str): The API key for authentication.
        intuit_tid (str): The transaction ID for tracking requests.
        log_level (str): The log level for logging messages. Default is "main".

    Raises:
        Exception: If the request to refresh metadata tags fails.
    """
    try:
        # Construct the refresh URL with the API key
        refresh_url = f"{METADATA_CATALOG_SVC_BASE_URL}/v1/metadata/cap/refresh-tag?intuit_apikey={api_key}"

        # Prepare the request body with environment and metadata service URL
        request_body = {"env": env, "metadataServiceUrl": codium_metadata_service_url}

        # Set the headers with content type and transaction ID
        headers = {"Content-Type": "application/json", "intuit_tid": intuit_tid}

        # Send a POST request to refresh metadata tags
        response = requests.post(
            refresh_url, headers=headers, data=json.dumps(request_body)
        )

        # Check if the response status is 202 (Accepted)
        if response.status_code == 202:
            print(
                f"[{log_level}] Refreshing metadata tags successful for env {env} with tid: {intuit_tid}."
            )
        else:
            # Log the failure and raise an exception
            print(
                f"[{log_level}] Failed to refresh metadata tags for env {env} with response status: {response.status_code} and tid: {intuit_tid}"
            )
            print(f"[{log_level}] Got response: {response.text} with tid: {intuit_tid}")
            raise Exception(
                f"An error occurred while refreshing metadata tags for env {env} with tid: {intuit_tid}."
            )
    except RequestException as e:
        # Handle request exceptions and log the error
        print(
            f"[{log_level}] An unexpected error occurred while refreshing metadata tags for env {env} with tid: {intuit_tid}. Error: {str(e)}"
        )
        raise Exception(
            f"An unexpected error occurred during the metadata tag refresh with tid: {intuit_tid}."
        ) from e


def get_metadata_record(capability_id, intuit_tid, log_level="main"):
    """
    Retrieves metadata for a given capability ID.

    Args:
        capability_id (str): The ID of the capability to fetch metadata for.
        intuit_tid (str): The transaction ID for tracking requests.
        log_level (str): The log level for logging messages. Default is "main".

    Returns:
        dict: The metadata record for the specified capability ID.

    Raises:
        Exception: If the request to get metadata fails or the capability ID does not exist.
    """
    try:
        print(f"[{log_level}] Fetching Metadata for capability ID: {capability_id}")

        # Retrieve the API key for authentication
        api_key = get_simple_auth_key()

        # Construct the URL to fetch metadata for the capability ID
        base_url = "https://metadata-catalog.api.intuit.com/v1/metadata"
        url = f"{base_url}/cap/{capability_id}?intuit_apikey={api_key}"

        # Set the headers with content type and transaction ID
        headers = {"Content-Type": "application/json", "intuit_tid": intuit_tid}

        # Send a GET request to retrieve metadata
        response = requests.get(url, headers=headers)

        # Check if the response status is 200 (OK)
        if response.status_code == 200:
            metadata = response.json()
            print(
                f"[{log_level}] Successfully fetched the metadata for capability ID {capability_id}"
            )
            return metadata
        elif response.status_code == 404:
            # Log the non-existence of the capability ID and raise an exception
            print(f"[{log_level}] Capability ID {capability_id} does not exist.")
            raise Exception(f"Capability ID {capability_id} does not exist.")
        else:
            # Log the failure and raise an exception
            print(
                f"[{log_level}] Failed to get metadata for capability ID {capability_id} with response status code: {response.status_code} and tid: {intuit_tid}."
            )
            print(f"[{log_level}] Got response: {response.text}")
            raise Exception(
                f"An error occurred while getting metadata for capability ID {capability_id}."
            )
    except requests.exceptions.RequestException as e:
        # Handle request exceptions and log the error
        print(
            f"[{log_level}] An unexpected error occurred while getting metadata from the catalog: {str(e)}"
        )
        raise Exception(f"An unexpected error occurred: {str(e)}")


def create_metadata_record(
    repo_url, capability_id, commit_hash, intuit_tid, log_level="main"
):
    """
    Creates a metadata record for a given capability ID.

    Args:
        repo_url (str): The URL of the repository.
        capability_id (str): The ID of the capability to create metadata for.
        commit_hash (str): The commit hash for the current state.
        intuit_tid (str): The transaction ID for tracking requests.
        log_level (str): The log level for logging messages. Default is "main".

    Returns:
        dict: The response from the metadata creation request.

    Raises:
        Exception: If the request to create metadata fails.
    """
    try:
        print(f"[{log_level}] Creating Metadata for capability ID: {capability_id}")

        # Retrieve the API key for authentication
        api_key = get_simple_auth_key()

        # Construct the URL to create metadata for the capability ID
        base_url = METADATA_CATALOG_SVC_BASE_URL
        url = f"{base_url}/v1/metadata/env/cli/cap/{capability_id}?intuit_apikey={api_key}"

        # Prepare the metadata payload with repository URL and commit hash
        metadata_payload = {"repo": repo_url, "current_commit": commit_hash}

        # Set the headers with content type and transaction ID
        headers = {"Content-Type": "application/json", "intuit_tid": intuit_tid}

        # Send a POST request to create metadata
        response = requests.post(
            url, headers=headers, data=json.dumps(metadata_payload)
        )

        # Check if the response status is 200 (OK)
        if response.status_code == 200:
            print(
                f"[{log_level}] Successfully created the metadata for capability ID {capability_id}."
            )
            return response.json()
        else:
            # Log the failure and raise an exception
            print(
                f"[{log_level}] Failed to create metadata for capability ID {capability_id} with response status code: {response.status_code} and tid: {intuit_tid}."
            )
            print(f"[{log_level}] Got response: {response.text}")
            raise Exception(
                f"An error occurred while creating metadata for capability ID {capability_id}."
            )
    except RequestException as e:
        # Handle request exceptions and log the error
        print(
            f"[{log_level}] An unexpected error occurred while creating metadata: {str(e)}"
        )
        raise Exception(f"An unexpected error occurred: {str(e)}")
