import os
import shutil

import requests
from git import Repo
from github import Github

from codegencli.scripts.constants.constants import (
    APP_INSTALLATION_ID,
    GITHUB_API_BASE_URL,
    GITHUB_ORG_NAME,
)
from codegencli.scripts.services.file import copy_folder, update_ai_config


def remove_git_suffix(git_url):
    """
    Removes the '.git' suffix from a Git URL if present.

    Args:
        git_url (str): The Git URL.
        log_level (str): The log level for logging messages.

    Returns:
        str: The Git URL without the '.git' suffix.
    """
    if git_url.endswith(".git"):
        git_url = git_url[:-4]
    return git_url


def prepare_repo(working_dir, capability, github_token, log_level="main"):
    """
    Prepares a GitHub repository for a given capability.

    Args:
        working_dir (str): The working directory containing the content to be copied.
        capability (str): The capability name for the repository.
        github_token (str): The GitHub token for authentication.
        log_level (str): The log level for logging messages.

    Returns:
        tuple: The local repository path, the repository URL without '.git', and the commit hash.
    """
    # Initialize GitHub API client
    g = Github(base_url=GITHUB_API_BASE_URL, login_or_token=github_token)
    # Get the organization object
    org = g.get_organization(GITHUB_ORG_NAME)

    # Get or create the repository
    repo = get_or_create_repo(org, capability, log_level)
    # Set up the local repository
    repo_path = setup_local_repo(capability, github_token, log_level)
    # Clear the repository directory
    clear_repo_directory(repo_path, log_level)
    # Copy content to the repository
    copy_content_to_repo(working_dir, repo_path, log_level)
    # Update the configuration
    update_configuration(repo_path, capability)
    # Commit and push changes
    commit_hash = commit_and_push_changes(repo_path, log_level)
    # Update GitHub app repositories
    update_github_app_repositories(repo.id, github_token, log_level)

    return repo_path, remove_git_suffix(repo.url), commit_hash


def get_or_create_repo(org, capability, log_level="main"):
    """
    Gets an existing repository or creates a new one if it doesn't exist.

    Args:
        org (github.Organization): The GitHub organization object.
        capability (str): The capability name for the repository.
        log_level (str): The log level for logging messages.

    Returns:
        github.Repository: The GitHub repository object.
    """
    try:
        # Try to get the existing repository
        repo = org.get_repo(capability)
        print(f"[{log_level}] Repository {capability} already exists.")
    except Exception:
        # Create a new repository if it doesn't exist
        repo = org.create_repo(
            name=capability, description=f"Repository for {capability}", private=True
        )
        print(f"[{log_level}] Repository {capability} created successfully.")

        # Create an initial commit to establish a branch
        repo.create_file("README.md", "Initial commit", "# Initial Commit\n")
        main_ref = repo.get_git_ref("heads/master")

        # Create the "next" branch from the initial commit
        repo.create_git_ref(ref="refs/heads/next", sha=main_ref.object.sha)
        print(f"[{log_level}] Branch 'next' created successfully.")

        # Set "next" as the default branch
        repo.edit(default_branch="next")
        print(f"[{log_level}] 'next' branch set as default branch.")

    return repo


def setup_local_repo(capability, github_token, log_level="main"):
    """
    Sets up a local clone of the repository, cloning only the specified branch.

    Args:
        capability (str): The capability name for the repository.
        github_token (str): The GitHub token for authentication.
        log_level (str): The log level for logging messages.

    Returns:
        str: The local path to the cloned repository.
    """
    # Define the local repository path
    repo_path = os.path.join("/tmp", capability)
    if os.path.exists(repo_path):
        # Remove the existing directory if it exists
        shutil.rmtree(repo_path)
        print(f"[{log_level}] Deleted existing directory {repo_path}.")

    # Construct the remote URL for cloning
    remote_url = (
        f"https://{github_token}@github.intuit.com/{GITHUB_ORG_NAME}/{capability}.git"
    )

    # Clone only the "next" branch of the repository
    Repo.clone_from(remote_url, repo_path, branch="next")
    print(
        f"[{log_level}] Repository {capability} cloned to {repo_path} with 'next' branch."
    )
    return repo_path


def clear_repo_directory(repo_path, log_level="main"):
    """
    Clears all files in the repository directory except the .git directory.

    Args:
        repo_path (str): The local path to the repository.
        log_level (str): The log level for logging messages.
    """
    for item in os.listdir(repo_path):
        item_path = os.path.join(repo_path, item)
        if item != ".git":
            if os.path.isdir(item_path):
                shutil.rmtree(item_path)
            else:
                os.remove(item_path)
    print(f"[{log_level}] Cleared all files in {repo_path} except .git directory.")


def copy_content_to_repo(working_dir, repo_path, log_level="main"):
    """
    Copies content from the working directory to the repository directory.

    Args:
        working_dir (str): The working directory containing the content to be copied.
        repo_path (str): The local path to the repository.
        log_level (str): The log level for logging messages.
    """
    copy_folder(working_dir, repo_path)
    print(f"[{log_level}] Copied content from {working_dir} to {repo_path}.")


def update_configuration(repo_path, capability):
    """
    Updates the AI configuration file in the repository.

    Args:
        repo_path (str): The local path to the repository.
        capability (str): The capability name for the repository.
        log_level (str): The log level for logging messages.
    """
    ai_config_path = os.path.join(repo_path, ".ai_config.toml")
    update_ai_config(ai_config_path, ["tags", "capability_id"], capability)


def commit_and_push_changes(repo_path, log_level="main"):
    """
    Commits and pushes local changes to the remote repository.

    Args:
        repo_path (str): The local path to the repository.
        log_level (str): The log level for logging messages.

    Returns:
        str: The commit hash of the pushed changes.
    """
    # Initialize the local repository object
    repo_local = Repo(repo_path)
    # Stage all changes
    repo_local.git.add(A=True)
    # Commit the changes
    commit = repo_local.index.commit("Local changes")
    # Push the changes to the remote repository
    origin = repo_local.remote("origin")
    origin.push(refspec="next:next")
    print(f"[{log_level}] Content pushed to the repository on next branch.")
    return commit.hexsha


def update_github_app_repositories(repo_id, github_token, log_level="main"):
    """
    Updates the GitHub app with the repository.

    Args:
        repo_id (int): The ID of the GitHub repository.
        github_token (str): The GitHub token for authentication.
        log_level (str): The log level for logging messages.
    """
    # Construct the API URL for updating the GitHub app
    url = f"{GITHUB_API_BASE_URL}/user/installations/{APP_INSTALLATION_ID}/repositories/{repo_id}"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {github_token}",
    }
    # Send a PUT request to the GitHub API
    response = requests.put(url, headers=headers)
    if response.status_code == 204:
        print(
            f"[{log_level}] Repository with ID {repo_id} successfully added to the GitHub app."
        )
    else:
        print(
            f"[{log_level}] Failed to add repository to the GitHub app {url}: {response.status_code} {response.text}"
        )
