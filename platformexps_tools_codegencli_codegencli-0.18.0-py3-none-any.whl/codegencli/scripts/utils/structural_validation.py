import os
import re

import toml


def structural_validation(directory):
    # Run folder structure validation
    validate_structure(directory)
    # Run Jenkinsfile validation
    validate_jenkinsfile(directory)
    # Run .ai_config.toml validation
    validate_ai_config(directory)


def validate_structure(directory):
    # Validate the folder structure
    required_dirs = ["code_examples", "validations"]
    required_files = ["Jenkinsfile", ".ai_config.toml"]

    for dir_name in required_dirs:
        dir_path = os.path.join(directory, dir_name)
        if not os.path.isdir(dir_path):
            print(f"Error: {dir_name} directory not found in {directory}!")
            raise Exception(f"Error: {dir_name} directory not found in {directory}!")

    for file in required_files:
        file_path = os.path.join(directory, file)
        if not os.path.isfile(file_path):
            print(f"Error: {file} file not found in {directory}!")
            raise Exception(f"Error: {file} file not found in {directory}!")

    # Check for test-suite.yaml in the validations directory
    test_suite_file = os.path.join(directory, "validations", "test-suite.yaml")
    if not os.path.isfile(test_suite_file):
        print(f"Error: test-suite.yaml file not found in validations directory!")
        raise Exception(
            "Error: test-suite.yaml file not found in validations directory!"
        )


def validate_jenkinsfile(directory):
    # Check if Jenkinsfile exists
    jenkinsfile_path = os.path.join(directory, "Jenkinsfile")
    if not os.path.isfile(jenkinsfile_path):
        print("Error: Jenkinsfile does not exist.")
        raise Exception()

    # Read the Jenkinsfile content
    with open(jenkinsfile_path, "r") as file:
        content = file.read()

    # Check for capabilityId and notifyAt parameters
    if not re.search(r"capabilityId:\s*'[^']+'", content):
        print("Error: Jenkinsfile must contain 'capabilityId' parameter.")
        raise Exception()
    if not re.search(r"notifyAt:\s*'[^']+'", content):
        print("Error: Jenkinsfile must contain 'notifyAt' parameter.")
        raise Exception()


def validate_ai_config(directory, log_id="main"):
    # Check if the file exists
    full_path = os.path.join(directory, ".ai_config.toml")
    if not os.path.isfile(full_path):
        print(f"Error: .ai_config.toml does not exist in {directory}.")
        raise Exception(f"Error: .ai_config.toml does not exist in {directory}.")

    try:
        # Load the TOML configuration file
        config = toml.load(full_path)
    except Exception as e:
        print(f"Error: Failed to parse .ai_config.toml: {e}")
        raise Exception(f"Error: Failed to parse .ai_config.toml: {e}")

    # Validate the file_filters section
    file_filters = config.get("file_filters", {})
    if not isinstance(file_filters, dict):
        print("Error: [file_filters] section must be a dictionary.")
        raise Exception("Error: [file_filters] section must be a dictionary.")

    # Retrieve include and exclude lists
    include = file_filters.get("include", [])
    exclude = file_filters.get("exclude", [])

    # Check if include is a list of strings
    if not isinstance(include, list) or not all(
        isinstance(item, str) for item in include
    ):
        print("Error: 'include' must be a list of strings.")
        raise Exception("Error: 'include' must be a list of strings.")

    # Ensure all include patterns start with 'code_examples/'
    if not all(item.startswith("code_examples/") for item in include):
        print("Error: All 'include' patterns must start with 'code_examples/'.")
        raise Exception(
            "Error: All 'include' patterns must start with 'code_examples/'."
        )

    # Check if exclude is a list of strings
    if not isinstance(exclude, list) or not all(
        isinstance(item, str) for item in exclude
    ):
        print("Error: 'exclude' must be a list of strings.")
        raise Exception("Error: 'exclude' must be a list of strings.")

    # Ensure 'validations/*' is in the exclude list
    if "validations/*" not in exclude:
        print("Error: 'exclude' list must contain 'validations/*'.")
        raise Exception("Error: 'exclude' list must contain 'validations/*'.")

    # Validate the tags section
    tags = config.get("tags", {})
    if not isinstance(tags, dict):
        print("Error: [tags] section must be a dictionary.")
        raise Exception("Error: [tags] section must be a dictionary.")

    # Ensure only 'capability_id' and 'capability_name' are present in tags
    if len(tags) != 2 or "capability_id" not in tags or "capability_name" not in tags:
        print(
            "Error: Only 'capability_id' and 'capability_name' are allowed in the tags section."
        )
        raise Exception(
            "Error: Only 'capability_id' and 'capability_name' are allowed in the tags section."
        )

    # If all checks pass, validation is successful
    print(f"[{log_id}] Validation completed successfully.")
