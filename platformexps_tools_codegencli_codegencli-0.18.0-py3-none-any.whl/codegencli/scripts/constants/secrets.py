import base64


def get_simple_auth_key():
    return decode_key("aU9qZWF1NEdpa29zZXJ5a2FkcnB4WTBlcGxNemRoamVpbXVZRjJTTg==")


def get_simple_auth_key_codegen():
    return decode_key("WjZ2cDRJWlBzZXJ5a2FkcnBlcnBHMUNoTkhFWTVLTkdUczF6RWRqSQ==")


def get_private_auth_key():
    return decode_key("eGRGWTBGbEdYM280SHZqTEFkcnBMODNyQ2JUSkV4V29HSTlWWFQzZw==")


def get_github_access_token():
    return decode_key("TFZPSzNtV1VNTW9ncTVLM19waGdoTFZ0MTJYb28zSnBNOUM3SVZOMw==")


def encode_key(original_key):
    # Split the key into two parts
    part1 = original_key[: len(original_key) // 2]
    part2 = original_key[len(original_key) // 2 :]

    # Reverse each part
    part1_reversed = part1[::-1]
    part2_reversed = part2[::-1]

    # Merge the parts back together
    merged_key = part1_reversed + part2_reversed

    # Base64 encode the merged key
    encoded_key = base64.b64encode(merged_key.encode()).decode()

    return encoded_key


def decode_key(encoded_key):
    # Base64 decode to get the merged key back
    decoded_key = base64.b64decode(encoded_key).decode()

    # Split the decoded key into two parts
    part1_reversed = decoded_key[: len(decoded_key) // 2]
    part2_reversed = decoded_key[len(decoded_key) // 2 :]

    # Reverse each part to retrieve the original parts
    part1 = part1_reversed[::-1]
    part2 = part2_reversed[::-1]

    # Merge the parts back to get the original key
    original_key_retrieved = part1 + part2

    return original_key_retrieved


def main():
    # Define the working directory
    print(get_simple_auth_key())


if __name__ == "__main__":
    main()
