import base64
import json
import os
import random
import socket
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urljoin, urlparse

import click
import requests


class CaptureHandler(BaseHTTPRequestHandler):
    captured_data = None
    server_should_stop = False

    def do_POST(self):
        if self.path == "/capture":
            content_length = int(self.headers["Content-Length"])
            post_data = self.rfile.read(content_length)

            try:
                CaptureHandler.captured_data = json.loads(post_data.decode("utf-8"))
                self.send_response(200)
                self.send_header("Content-type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(json.dumps({"status": "success"}).encode("utf-8"))

                # Signal to stop the server after successful capture
                CaptureHandler.server_should_stop = True
            except json.JSONDecodeError:
                self.send_response(400)
                self.send_header("Content-type", "application/json")
                self.end_headers()
                self.wfile.write(
                    json.dumps({"status": "error", "message": "Invalid JSON"}).encode(
                        "utf-8"
                    )
                )
        else:
            self.send_response(404)
            self.send_header("Content-type", "application/json")
            self.end_headers()
            self.wfile.write(
                json.dumps({"status": "error", "message": "Not found"}).encode("utf-8")
            )

    def log_message(self, format, *args):
        # Suppress log messages
        return


def find_available_port():
    """Find a random available port"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


def run_capture_server(port):
    """Run a temporary HTTP server to capture auth details"""
    server_address = ("", port)
    httpd = HTTPServer(server_address, CaptureHandler)

    # Run the server in a separate thread until we get the data
    def serve_until_capture():
        while not CaptureHandler.server_should_stop:
            httpd.handle_request()
        httpd.server_close()

    server_thread = threading.Thread(target=serve_until_capture)
    server_thread.daemon = True
    server_thread.start()

    return httpd, server_thread


def create_proxy_tunnel(
    userid, token, model_name="anthropic.claude-3-haiku-20240307-v1-0", tunnel_port=5000
):
    """
    Create a proxy tunnel to access Intuit's LLM model

    Args:
        userid (str): Intuit user ID
        token (str): Intuit authentication token
        model_name (str): Name of the LLM model to use
        tunnel_port (int): Local port to use for the tunnel
    """
    click.echo(f"Creating proxy tunnel with UserID: {userid}")
    click.echo(f"Using model: {model_name}")

    # Create tunnel server
    base_url = "https://llmexecution-e2e.api.intuit.com"
    model_path = f"/v3/{model_name}"
    click.echo(f"All requests will be forwarded to: {base_url}{model_path}/* endpoints")

    class ProxyTunnelHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            self._handle_request("GET")

        def do_POST(self):
            self._handle_request("POST")

        def do_PUT(self):
            self._handle_request("PUT")

        def do_DELETE(self):
            self._handle_request("DELETE")

        def do_HEAD(self):
            self._handle_request("HEAD")

        def do_OPTIONS(self):
            self._handle_request("OPTIONS")

        def do_PATCH(self):
            self._handle_request("PATCH")

        def _handle_request(self, method):
            # Read the request body if present
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length) if content_length > 0 else None

            # Process request body if it's JSON
            modified_body = body
            request_model = model_name  # Default to CLI parameter

            if body:
                try:
                    # Parse JSON
                    json_body = json.loads(body)

                    # Extract model if present in the request
                    if "model" in json_body:
                        request_model = json_body["model"]
                        # Keep model in the payload

                    # Remove specified parameters if they exist at top level
                    fields_to_remove = [
                        "stream",
                        "stream_options",
                    ]  # model is no longer removed
                    modified = False

                    for field in fields_to_remove:
                        if field in json_body:
                            del json_body[field]
                            modified = True

                    # Set temperature to 1 if present
                    if "temperature" in json_body:
                        json_body["temperature"] = 1
                        modified = True

                    # Convert back to bytes if any modifications were made
                    if modified:
                        modified_body = json.dumps(json_body).encode("utf-8")
                except json.JSONDecodeError:
                    # Not valid JSON, leave body as is
                    pass

            # Construct the target URL using the model from the request or CLI
            request_model_path = f"/v3/{request_model}"

            if self.path.startswith("/"):
                # Combine model path with the requested path
                request_path = request_model_path + self.path
            else:
                request_path = request_model_path + "/" + self.path

            url = urljoin(base_url, request_path)

            # Log incoming request
            click.echo("\n=== INCOMING REQUEST ===")
            click.echo(f"Method: {method}")
            click.echo(f"Path: {self.path}")
            click.echo(f"Using model: {request_model}")
            click.echo(f"Forwarding to: {url}")
            click.echo("Headers:")
            for header, value in self.headers.items():
                click.echo(f"  {header}: {value}")
            if body:
                try:
                    # Try to pretty-print if it's JSON
                    json_body = json.loads(body)
                    json_str = json.dumps(json_body, indent=2)
                    click.echo("Body (JSON):")
                    click.echo(json_str)
                except json.JSONDecodeError:
                    # Otherwise print as string (without truncation)
                    body_str = body.decode("utf-8", errors="replace")
                    click.echo(f"Body: {body_str}")

            # Prepare headers
            headers = {
                key: value
                for key, value in self.headers.items()
                if key.lower() not in ("host", "content-length")
            }

            # Add the required headers
            headers["intuit_experience_id"] = "5417bd43-1e9b-44e0-9a2f-31cbd351434a"
            auth_header = (
                f"Intuit_IAM_Authentication intuit_appid=Intuit.platformexps.tools.codiumaicodiumate,"
                f"intuit_app_secret=preprd7GHDUP2o8qdIBkoyTz0Wq2fMUiP6OSjYiT,"
                f"intuit_token_type=IAM-Ticket,"
                f"intuit_userid={userid},"
                f"intuit_token={token}"
            )
            headers["Authorization"] = auth_header

            # Log outgoing request with modified body if JSON
            click.echo("\n=== OUTGOING REQUEST ===")
            click.echo(f"URL: {url}")
            click.echo(f"Method: {method}")
            click.echo("Headers:")
            for header, value in headers.items():
                # Mask sensitive information in auth header
                if header.lower() == "authorization":
                    masked_value = value
                    if "intuit_token=" in value:
                        token_parts = value.split("intuit_token=")
                        if len(token_parts) > 1:
                            token_value = (
                                token_parts[1].split(",")[0]
                                if "," in token_parts[1]
                                else token_parts[1]
                            )
                            masked_token = (
                                token_value[:5]
                                + "*" * (len(token_value) - 10)
                                + token_value[-5:]
                                if len(token_value) > 10
                                else "****"
                            )
                            masked_value = value.replace(token_value, masked_token)
                    click.echo(f"  {header}: {masked_value}")
                else:
                    click.echo(f"  {header}: {value}")
            if modified_body:
                try:
                    # Try to pretty-print if it's JSON
                    json_body = json.loads(modified_body)
                    json_str = json.dumps(json_body, indent=2)
                    click.echo("Body (JSON):")
                    click.echo(json_str)
                except json.JSONDecodeError:
                    # Otherwise print as string (without truncation)
                    body_str = modified_body.decode("utf-8", errors="replace")
                    click.echo(f"Body: {body_str}")

            try:
                # Forward the request to the target server with the modified body
                response = requests.request(
                    method=method,
                    url=url,
                    headers=headers,
                    data=modified_body,
                    stream=True,
                    verify=True,
                    allow_redirects=False,
                )

                # Log the response
                click.echo("\n=== RESPONSE ===")
                click.echo(f"Status code: {response.status_code}")
                click.echo("Headers:")
                for header, value in response.headers.items():
                    click.echo(f"  {header}: {value}")

                # Try to log the response body
                try:
                    # Attempt to parse as JSON for pretty printing
                    json_content = response.json()
                    json_str = json.dumps(json_content, indent=2)
                    click.echo("Body (JSON):")
                    click.echo(json_str)
                except (json.JSONDecodeError, ValueError):
                    # If not JSON, get as text without truncation
                    body_text = response.text
                    click.echo(f"Body: {body_text}")
                except Exception as e:
                    click.echo(f"Could not decode response body: {str(e)}")

                # Send the response status code
                self.send_response(response.status_code)

                # Send the response headers
                for header, value in response.headers.items():
                    if header.lower() not in ("transfer-encoding", "connection"):
                        self.send_header(header, value)
                self.end_headers()

                # Send the response body
                if response.content:
                    self.wfile.write(response.content)

            except Exception as e:
                click.echo(f"\n=== ERROR ===\n{str(e)}")
                self.send_response(500)
                self.send_header("Content-type", "application/json")
                self.end_headers()
                error_response = json.dumps({"error": str(e)}).encode("utf-8")
                self.wfile.write(error_response)

        def log_message(self, format, *args):
            # Customized logging
            click.echo(f"Proxy: {args[0]} {args[1]} {args[2]}")

    # Start the tunnel server
    try:
        server = HTTPServer(("", tunnel_port), ProxyTunnelHandler)
        server_thread = threading.Thread(target=server.serve_forever)
        server_thread.daemon = True
        server_thread.start()

        click.echo(f"Tunnel created successfully! Listening on port {tunnel_port}")
        click.echo(
            f"You can now access Intuit's LLM model via http://localhost:{tunnel_port}"
        )
        click.echo("Press Ctrl+C to stop the tunnel")

        # Keep the main thread running to ensure the tunnel stays open
        try:
            while True:
                threading.Event().wait(100)
        except KeyboardInterrupt:
            click.echo("Shutting down tunnel...")
            server.shutdown()

    except OSError as e:
        if e.errno == 48:  # Address already in use
            click.echo(
                f"Error: Port {tunnel_port} is already in use. Please free up the port and try again."
            )
        else:
            click.echo(f"Error starting tunnel: {str(e)}")
        return False

    return True


def start_proxy_tunnel(
    model_name="anthropic.claude-3-haiku-20240307-v1-0", tunnel_port=5000
):
    """
    Start a proxy tunnel to access Intuit's LLM model

    Args:
        model_name (str): Name of the LLM model to use
        tunnel_port (int): Local port to use for the tunnel
    """
    click.echo(
        f"Starting proxy tunnel to Intuit's LLM model (Model: {model_name}, Port: {tunnel_port})..."
    )

    # Find an available port
    port = find_available_port()
    click.echo(f"Starting local capture server on port {port}")

    # Start the server
    httpd, server_thread = run_capture_server(port)

    # Create the capture URL
    capture_url = f"http://127.0.0.1:{port}/capture"

    # Base64 encode the capture URL
    encoded_capture_url = base64.b64encode(capture_url.encode("utf-8")).decode("utf-8")

    # Open the browser to the signin page with the encoded capture URL as a query parameter
    signin_url = (
        f"https://pr-agent-access-qal.app.intuit.com/signin?reply={encoded_capture_url}"
    )
    click.echo(f"Opening browser to signin page with capture URL: {capture_url}")
    click.echo(f"Waiting for authentication. Please sign in through the browser...")
    webbrowser.open(signin_url)

    # Wait for the server thread to complete (when data is captured)
    server_thread.join(timeout=300)  # 5 minute timeout

    if CaptureHandler.captured_data:
        userid = CaptureHandler.captured_data.get("intuit_userid")
        token = CaptureHandler.captured_data.get("intuit_token")

        if userid and token:
            create_proxy_tunnel(userid, token, model_name, tunnel_port)
        else:
            click.echo("Error: Missing userid or token in captured data")
            return False
    else:
        click.echo("Error: No authentication data captured. Timeout or server error.")
        return False

    return True


def main():
    start_proxy_tunnel()


if __name__ == "__main__":
    main()
